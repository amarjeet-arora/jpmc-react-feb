import logo from './logo.svg';
import './App.css';
import CounterApp from './components/CounterApp';
import AuthComp from './components/AuthComp';

function App() {
  return (
    <div className="App">
     React Redux App
     <hr/>
     <CounterApp/>
     <AuthComp/>
    </div>
  );
}

export default App;
