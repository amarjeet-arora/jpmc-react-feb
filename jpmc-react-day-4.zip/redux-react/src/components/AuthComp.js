



import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { login, logout } from '../redux/actions/authActions';

function AuthComp(props) {
    const authUser= useSelector(state => state.auth)
    const dispatch=useDispatch()
    return (
        <div>
            <h2>Only for Authorized users only....!</h2>
          
            {authUser ? (
                <div>
                    <p>  Congratulations....! you got 50% off... use HJYU6789YU to avail this</p>
                  
                    </div>
            ) :(
                <p>Login to see the offers</p>
            )}
            <hr/>
            <button onClick={()=> dispatch(login())}>Login</button>
            <button onClick={()=> dispatch(logout())}>Logout</button>
        </div>
    );
}

export default AuthComp;