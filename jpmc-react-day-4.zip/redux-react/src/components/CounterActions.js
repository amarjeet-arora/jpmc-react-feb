


import React from 'react';
import { useDispatch } from 'react-redux';
import { decrement, increment } from '../redux/actions/counterAction'
function CounterActions(props) {
    const dispatch=useDispatch()

    return (
        <div>
            <button onClick={()=>dispatch(increment())}>+</button>
            <button onClick={()=>dispatch(decrement())}>-</button>
        </div>
    );
}

export default CounterActions;