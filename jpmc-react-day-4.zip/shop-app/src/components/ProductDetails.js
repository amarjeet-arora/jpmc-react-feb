import React from 'react';
import { useParams } from 'react-router-dom';

function ProductDetails(props) {
    const {productid} =useParams()
    console.log(productid);
    return (
        <div>
            details
        </div>
    );
}

export default ProductDetails;