import React, { useEffect } from "react";
import ProductComponent from "./ProductComponent";
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import { setProduct } from "../redux/actions/productActions";

function ProductListing(props) {
  const dispatch = useDispatch();
  const products= useSelector(state=> state.allProducts.products)

  const fetchProducts = async () => {
    const response = await axios.get("https://fakestoreapi.com/products");
    
    dispatch(setProduct(response.data))
  };
  useEffect(() => {
    fetchProducts();
  }, []);
console.log(products);

  return (
    <div className="ui grid container">
      <ProductComponent />
    </div>
  );
}

export default ProductListing;
