import React from "react";

import LandingPage from "./components/LandingPage";
import Login from "./components/Login";
import PageNotFound from "./components/PageNotFound";
import Portfolio from "./components/Portfolio";
//import Register from "./components/Register";
import UserDetails from "./components/UserDetails";
const Register=React.lazy(()=> import('./components/Register'))


export const routes=[
    {path:"/",element:<LandingPage/>},
    {path:"/login",element:<Login/>},
    {path:"/register",element:<React.Suspense fallback="loading page....!"><Register/></React.Suspense> },
    {path:"/userdetails/:userid",element:<UserDetails/>},
    {path:"/portfolio",element:<Portfolio/>},
    {path:"*",element:<PageNotFound/>},

]