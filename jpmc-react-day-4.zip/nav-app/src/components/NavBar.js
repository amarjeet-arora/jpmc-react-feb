

import React from 'react';
import { Link, Router } from 'react-router-dom'
function NavBar(props) {
    return (  
        <div>

        
  <nav className="nav">
     
  <li><Link className="nav-link" to="/login">Login</Link></li>
  <li><Link className="nav-link" to="/register">Register</Link></li>
  <li><Link className="nav-link" to="/userdetails">UserDetails</Link></li>
  <li><Link className="nav-link" to="/portfolio">Portfolio</Link></li>
 
  
</nav>  

        </div>
    );
}

export default NavBar;