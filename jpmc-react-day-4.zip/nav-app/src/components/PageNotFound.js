import React from 'react';

function PageNotFound(props) {
    return (
        <div className='container'>
            <p>OOPS.....Page Not Found</p>
        </div>
    );
}

export default PageNotFound;