import React from 'react';

function LandingPage(props) {
    return (
        <div className='container'>
            Welcome to JPMC React App
        </div>
    );
}

export default LandingPage;