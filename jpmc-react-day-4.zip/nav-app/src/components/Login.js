import React from 'react';

function Login(props) {
    return (
        <div className='container'>
            <p> User Login</p>
         
  <div class="input-group mb-3">
  <input type="text" className="form-control" placeholder="Username"  />
  <input type="text" className="form-control" placeholder="Password"  />
 
  <button className='btn btn-primary'>Login</button>
</div>

        </div>
    );
}

export default Login;