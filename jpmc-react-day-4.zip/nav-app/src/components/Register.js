import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'
function Register(props) {
    
    const [formData,setFormData]=useState({})
    const navigate=useNavigate()
    const handleData=(e)=>{
        setFormData({
            ...formData,[e.target.name]:e.target.value
        })
        console.log(formData);
    }
    const addUser=(e)=>{
     e.preventDefault();
     const data= JSON.stringify(formData)
     localStorage.setItem('udata',data)
    navigate("/login")
    }
    return (
        <div className='container'>
            <p> User Registeration</p>
         
  <div class="input-group mb-3">
    <form onSubmit={addUser}> 
  <input type="text" className="form-control" placeholder="Username" name="uname" onChange={handleData} />
  <input type="text" className="form-control" placeholder="Password" name="password" onChange={handleData} />
  <input type="text" className="form-control" placeholder="Email" name="email" onChange={handleData} />
  <input type="text" className="form-control" placeholder="City" name="city" onChange={handleData}/>
  <button className='btn btn-primary'>Register</button>
  </form>
</div>

        </div>
    );
}

export default Register;