



import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { getUsers } from '../redux/userState';
function UserApp(props) {
    const data= useSelector(state=> state.userdata.users)

    const dispatch=useDispatch()

    useEffect(()=>{
        dispatch(getUsers())
    },[])
    return (
        <div>
            
        </div>
    );
}

export default UserApp;