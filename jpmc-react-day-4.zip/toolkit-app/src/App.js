import logo from './logo.svg';
import './App.css';
import CounterApp from './components/components/CounterApp';

function App() {
  return (
    <div className="App">
       <CounterApp/>
    </div>
  );
}

export default App;
