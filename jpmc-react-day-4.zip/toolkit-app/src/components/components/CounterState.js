


import React from 'react';
import { useSelector } from 'react-redux';

function CounterState(props) {
    const capp= useSelector(state => state.count.counter)
    return (
        <div>
            <p>The Counter is :{capp}</p>
            
        </div>
    );
     
}

export default CounterState;