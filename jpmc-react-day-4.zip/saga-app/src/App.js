import logo from './logo.svg';
import './App.css';
import {useEffect} from 'react'
import {useDispatch} from 'react-redux'
import { getUserFetch } from './redux/actions';
function App() {
  const dispatch=useDispatch()

  useEffect(()=>{
dispatch(getUserFetch())
  },[])
  return (
    <div className="App">
      
    </div>
  );
}

export default App;
