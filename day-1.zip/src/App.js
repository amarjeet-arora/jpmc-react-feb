import logo from './logo.svg';
import './App.css';
import MainApp from './components/MainApp';
import Counter from './components/Counter';
import RestApplication from './restapp/RestApplication';

function App() {
  return (
    <div className="App">
       Welcome
       <MainApp/>
       <RestApplication/>
      
    </div>
  );
}

export default App;
