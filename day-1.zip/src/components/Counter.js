


import React, { Component } from 'react'

export default class Counter extends Component {
    //init the state
    state={
        count:0
    }
    increment=()=>{
        this.setState((prevState)=>{
            return{
                count:prevState.count+1
            }
        })
    }
  render() {
    return (
      <div>
        <p>The Counter is: {this.state.count}</p>
        <button onClick={this.increment}>inc</button>
      </div>
    )
  }
}
