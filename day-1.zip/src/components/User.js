import React, { Component } from "react";

export default class User extends Component {
  render() {
    return <div>
    <ul className="list-group">
  <li className="list-group-item">{this.props.ud}</li>
 
</ul>
<button onClick={()=> this.props.duser(this.props.ud)}>delete</button>
    </div>;
  }
}
