import { Component } from "react";
import Header from "./Header";
import Footer from "./Footer";
import AddUser from "./AddUser";
import Users from "./Users";

export default class MainApp extends Component {
  state = {
    headerMessage: "welcome to header",
    footerMessage: "welcome to Footer",
    users: [],
  };
//=======================Lifecycle===================

componentDidMount(){
  const json=localStorage.getItem('jpmc')
  const users=JSON.parse(json)
  if(users){
    this.setState(()=>{
      return{
        users
      }
    })
  }
}
componentDidUpdate(){
  const json= JSON.stringify(this.state.users)
  localStorage.setItem('jpmc',json)
}

  //operations
  //=================================================================//
  deleteUser = (user) => {
    this.setState((prevState) => {
      return {
        users: prevState.users.filter((option) => user !== option),
      };
    });
  };
  addUser = (user) => {
    this.setState((prevState) => {
      return {
        users: prevState.users.concat(user),
      };
    });
    console.log(this.state.users);
  };
  deleteAll = () => {
    this.setState(() => {
      return {
        users: [],
      };
    });
  };


  //==============Rendering=============================
  render() {
    return (
      <div>
        <Header hm={this.state.headerMessage} />
        Welcome to mainapp
        <Users
          udata={this.state.users}
          da={this.deleteAll}
          hasData={this.state.users.length > 0}
          du={this.deleteUser}
        />
        <AddUser au={this.addUser} />
        <Footer fm={this.state.footerMessage} />
      </div>
    );
  }
}
