import React, { Component } from "react";

export default class AddUser extends Component {
  adduser = (e) => {
    e.preventDefault();
    const uname = e.target.elements.uname.value;
    //const email = e.target.elements.email.value;

      this.props.au(uname)
  };
  render() {
    return (
      <div>
        <form onSubmit={this.adduser}>
          UserName:
          <input type="text" name="uname" />
         
          <button className="btn btn-primary">Add User</button>
        </form>
      </div>
    );
  }
}
