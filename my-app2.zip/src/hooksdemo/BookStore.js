import React, { useEffect, useState } from "react";

function BookStore(props) {
  const [users, setUsers] = useState([]);
  const [uname, setUname] = useState("");
  const [email, setEmail] = useState("");

  // call during loadtime only (componentdidmount)
  useEffect(() => {
    const udata = JSON.parse(localStorage.getItem("jpmc"));
    if (udata) {
      setUsers(udata);
    }
  }, []);
  // call during update state only (componentdidupdate)
  useEffect(() => {
    localStorage.setItem("jpmc", JSON.stringify(users));
  }, [users]);

  const addUser = (e) => {
    e.preventDefault();
    setUsers([...users, { uname, email }]);
    setUname("");
    setEmail("");
  };
  const deleteUser = (usr) => {
    setUsers(users.filter((user) => user.uname !== usr));
  };
  return (
    <div>
      {users.map((user) => (
        <div key={user.email}>
          {user.uname}- {user.email}
          <button
            className="btn btn-danger"
            onClick={() => deleteUser(user.uname)}
          >
            delete
          </button>
        </div>
      ))}
      <form onSubmit={addUser}>
        UserName:
        <input
          type="text"
          value={uname}
          onChange={(e) => setUname(e.target.value)}
        />
        Email:
        <input
          type="text"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button className="btn btn-primary">Add</button>
      </form>
    </div>
  );
}

export default BookStore;
