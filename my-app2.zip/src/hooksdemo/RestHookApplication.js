import React, { Component, useEffect, useState } from "react";
import axios from "axios";
const URL = "https://jsonplaceholder.typicode.com/users";
function RestHookApplication() {
  const [users, setUsers] = useState([]);
  useEffect(() => {
    axios
      .get(URL)
      .then((response) => response.data)
      .then((data) => {
        setUsers(data);
      }, []);
  });

  return (
    <div>
      {users.map((user) => (
        <div key={user.id}>
          {user.username} -{user.email}
        </div>
      ))}
    </div>
  );
}

export default RestHookApplication;
