

import React, { useEffect, useState } from 'react';

function Example1(props) {
    //init the state
    const [counter,setCounter]=useState(10)
// call during loadtime only (componentdidmount)
    useEffect(()=>{
        console.log('called during load');
    },[])
// call during update state only (componentdidupdate)
    useEffect(()=>{
        console.log('called during update');
    },[counter])
    return (
        <div>
            <p>The Count is : {counter}</p>
            <button onClick={()=>setCounter(counter+1)}>INC</button>
        </div>
    );
}

export default Example1;