import React, { Component } from "react";

class CustomError extends Component {
  state = {
    hasError: null,
  };
  static getDerivedStateFromError(error){
    return {hasError:true}
  }
  
  render() {
    if (this.state.hasError) {
      return (
        <div>
          <h2>We are having problem to load the address....!  </h2>
        </div>
      );
    } else {
      return this.props.children;
    }
  }
}

export default class Lsp extends Component {
  state = {
    quantity: "",
    address: "",
  };
  addressChanged = (val) => {
    this.setState({ address: val });
  };
  quantityChanged = (val) => {
    this.setState({ quantity: val });
  };

  render() {
    return (
      <div>
        Welcome to Product Order Screen
        <hr />
        <Order quantity={this.state.quantity} oqc={this.quantityChanged} />
        <hr />
        <Address address={this.state.address} ac={this.addressChanged} />
        <hr />
        <Summary
          quantity={this.state.quantity}
          oqc={this.quantityChanged}
          address={this.state.address}
        />
      </div>
    );
  }
}

class Order extends Component {
  changeQty = (e) => {
    this.props.oqc(e.target.value);
  };
  render() {
    return (
      <div>
        <p>
          Product Name
          <select>
            <option>Product-1</option>
            <option>Product-2</option>
            <option>Product-3</option>
          </select>
        </p>
        <p>
          Enter Quantity:
          <input
            type="text"
            value={this.props.quantity}
            onChange={this.changeQty}
          />
        </p>
      </div>
    );
  }
}

class Address extends Component {
  changeAdd = (e) => {
    this.props.ac(e.target.value);
  };
  render() {
    return (
      <div>
        <p>Adreess Details</p>
        Address:
        <input value={this.props.address} onChange={this.changeAdd} />
        <p>
          {" "}
          <CustomError>
          <TempAddress />
          </CustomError>
         
        </p>
      </div>
    );
  }
}
class TempAddress extends Component {
  render() {
    throw new Error("Not able to load Address....!");
    return (
      <div>
        <p>Temp Adreess Details</p>
        Address: B786, Pune West MH-411089
      </div>
    );
  }
}
class Summary extends Component {
  changeQty = (e) => {
    this.props.oqc(e.target.value);
  };
  render() {
    return (
      <div>
        <p> Order Summary</p>
        <p>Product Name: </p>
        <p>
          Update Quantity:
          <input
            type="text"
            value={this.props.quantity}
            onChange={this.changeQty}
          />
        </p>
        <p>Address: {this.props.address}</p>
      </div>
    );
  }
}
