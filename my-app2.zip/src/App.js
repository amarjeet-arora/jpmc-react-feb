import logo from './logo.svg';
import './App.css';
 
import Example1 from './hooksdemo/Example1';
import BookStore from './hooksdemo/BookStore';
import RestHookApplication from './hooksdemo/RestHookApplication';
import ContextApp from './hooksdemo/ContextApp';
import Lsp from './lsp/Lsp';

function App() {
  return (
    <div className="App">
       
      <Lsp/>
      
    </div>
  );
}

export default App;
