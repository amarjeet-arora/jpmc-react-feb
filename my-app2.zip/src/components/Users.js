 import User from "./User";

function Users (props) {
   
    return (
      <div>
        {props.udata.map((data) => (
          <User key={data} ud={data}  duser={props.du}/>
        ))}
        <button className="btn btn-danger" disabled={!props.hasData} onClick={props.da}>Delete All</button>
      </div>
    );
  }
export default Users