import React, { Component } from "react";

function AddUser(props) {
  const adduser = (e) => {
    e.preventDefault();
    const uname = e.target.elements.uname.value;

    props.au(uname);
  };

  return (
    <div>
      <form onSubmit={adduser}>
        UserName:
        <input type="text" name="uname" />
        <button className="btn btn-primary">Add User</button>
      </form>
    </div>
  );
}
export default AddUser;
