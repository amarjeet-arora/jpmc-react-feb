 
function User(props) {
  
    return <div>
    <ul className="list-group">
  <li className="list-group-item">{props.ud}</li>
 
</ul>
<button onClick={()=>props.duser(props.ud)}>delete</button>
    </div>;
  }

export default User